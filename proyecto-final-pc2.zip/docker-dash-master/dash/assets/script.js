window.onscroll = function() {myFunction()};

