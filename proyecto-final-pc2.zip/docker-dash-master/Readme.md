# Proyecto final PC2



## Notes

Cuando ingrese al jupyter notebook ya sea en play with docker o en entorno local le pedirá una contraseña, esta es "password" sin las comillas, una vez dentro vaya dentro del directorio work y ahí encontrara el archivo connection que contiene el código. Corra las celdas en orden para asegurar que las variables usadas en celdas posteriores existan